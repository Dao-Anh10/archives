<h1><?= $this->page ?></h1>
<a>Add</a>
<table>
    <thead>
        <tr>
            <td>ID</td>
            <td>Title</td>
            <td>Name</td>
        </tr>
    </thead>

    <tbody>

    </tbody>
</table>