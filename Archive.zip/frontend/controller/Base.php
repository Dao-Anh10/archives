<?php

namespace Frontend\Controller;

use Kernel\View;

class Base {
    public $view;

    public function init() {
        $this->view = new View;
    }
}