<?php

namespace Frontend\Controller;

use Model\Book;

use Kernel\Model;

class Index extends Base {
    public function index() {
        $this->view->page = 'Index-index';

        $this->view->render('index/index');
    }

    public function other() {
        $this->view->page = 'Index-other';

        $this->view->render('index/other');
    }
}