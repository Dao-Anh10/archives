<?php

namespace Frontend\Controller;

use Model\Book;

class SitePreference extends Base {
    public function index() {
        $model = new Book;

        $this->view->data = $model->getData();

        $this->view->layout = 'base';

        $this->view->page = 'Frontend-SitePreference-index';

        $this->view->render('site-preference/index');
    }

    public function getPreference($request) {
        echo 'Day la SitePreference-getPreference';

        var_dump($request);
    }
}