<h1><?= $this->page ?></h1>
<?= $this->data ?>