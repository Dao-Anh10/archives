<html>

<head>

</head>

<body>
    <div class="header">
        Header Base
    </div>

    <?php $this->placeholder() ?>

    <div class="footer">
        Copyright@
    </div>
</body>
</html>