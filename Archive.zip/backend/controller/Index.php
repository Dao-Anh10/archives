<?php

namespace Backend\Controller;

use Model\Book;

class Index extends Base {
    public function index($request) {
        $model = new Book;

        $this->view->data = $model->getData();

        $this->view->page = 'Backend-Index-index';

        $this->view->render('index/index');
    }

    public function run() {
        echo 'Day la trang run cua controller Index';
    }
}