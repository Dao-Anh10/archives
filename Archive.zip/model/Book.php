<?php

namespace Model;

use Kernel\Model;

class Book extends Model {

}