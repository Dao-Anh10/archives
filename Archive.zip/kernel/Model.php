<?php

namespace Kernel;

class Model {
    public $conn;

    public function __construct() {
        $this->conn = Db::getInstance();
    }

    public function getAllBySql($sql, $binding = null) {
        $sth = $this->conn->prepare($sql);

        $sth->execute($binding);

        return $sth->fetchAll(\PDO::FETCH_OBJ);
    }

    public function getBySql($sql, $binding = null) {
        $sth = $this->conn->prepare($sql);

        $sth->execute($binding);

        return $sth->fetch(\PDO::FETCH_OBJ);
    }


}