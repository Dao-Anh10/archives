<?php

return [
    'db' => [
        'host' => '',
        'username' => '',
        'password' => '',
        'dbname' => ''
    ]
];